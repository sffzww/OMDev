#define MICO_CONF_IMR
#include <CORBA-SMALL.h>
#ifdef HAVE_ANSI_CPLUSPLUS_HEADERS
#include <iostream>
#include <fstream>
#else
#include <iostream.h>
#include <fstream.h>
#endif
#include "hello.h"


using namespace std;

class Hello_impl : virtual public Hello_skel {
public:
    char *sayHello (const char *s)
    {
	cout << s << endl;
	return CORBA::string_dup (s);
    }
};

int
main (int argc, char *argv[])
{
    CORBA::ORB_var orb = CORBA::ORB_init (argc, argv, "mico-local-orb");
    CORBA::BOA_var boa = orb->BOA_init (argc, argv, "mico-local-boa");

    Hello_impl * hi = new Hello_impl;

    ofstream of ("server.ref");
    CORBA::String_var str = orb->object_to_string (hi);
    of << str.in() << endl;
    of.close ();

    boa->impl_is_ready (CORBA::ImplementationDef::_nil());
    orb->run ();
    return 0;
}
