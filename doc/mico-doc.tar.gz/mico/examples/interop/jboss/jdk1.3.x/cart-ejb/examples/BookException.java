package examples;

public class BookException extends Exception {

    public BookException() {
    }

    public BookException(String msg) {
        super(msg);
    }
}
