
/* lp_solve.cpp : Defines the entry point for the DLL. */

#include "lp_solveDLL.h"


BOOL APIENTRY DllMain( HANDLE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
           )
{
    return TRUE;
}

