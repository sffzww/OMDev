/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Tue Jun 04 20:00:46 2002
 */
/* Compiler settings for D:\OPCServer2\OPCExt2\Opcext2.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ISimulationControl = {0x416E6DA4,0xF554,0x11d5,{0xBB,0xF0,0x00,0x01,0x02,0x35,0xE4,0x9A}};


const IID IID_ITrainingControlCallBack = {0x416E6DA5,0xF554,0x11d5,{0xBB,0xF0,0x00,0x01,0x02,0x35,0xE4,0x9A}};


const IID IID_ITrainingControl = {0x416E6DA6,0xF554,0x11d5,{0xBB,0xF0,0x00,0x01,0x02,0x35,0xE4,0x9A}};


#ifdef __cplusplus
}
#endif

