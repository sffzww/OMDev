// SimpleOPCCLient.cpp
//
// A demonstration of the most frequently used OPC functionality
// Creating of groups and items, and synchronous reading and writing
// 
// (c) COPYRIGHT 2000, VTT Automation, VTT Energy and Fortum Engineering.
// Code is provided as-is and without warranty. 
//
// Written by Pasi Laakso, Jyrki Peltoniemi, Matti Paljakka and Tuomas Miettinen
// based on code provided by Al Chisholm 
// See also OPC Programmers' Connection
// http://www.opc.dial.pipex.com/
//
//
// This works with OpenModelica OPC server. Note that OPCExt1 and OPCExt2 interfaces
// are not interchangeable.
//

#include <string>

//Input/output
#include <iostream>
using namespace std;

// The OPC header file produced by MIDL compiler
#include "opc.h"
#include "opcext2.h"

// Error code descriptions
#include "checkOpcHresult.h"	   

int main()
{
	char chServerName[81];       // OPC server name, input from user
	WCHAR pWCHServerName[81];    // Program Id, i.e. OPC server name in wide characters

	size_t i, j;                 // Indices needed in looping over various tables

	// Pointer to COM interface IUnknown, the superclass of all COM interfaces
	IUnknown *pUnknown = 0;      
	// Return value used to indicate the success of various COM operations
	HRESULT hres;                
	
	// Ask the user to enter a server name
	cout << "Enter Server PROGID. Press Return to use OpenModelica.OPCUA.1" << endl;
	cin.getline(chServerName,81);
	if(*chServerName=='\0') {
		strcpy(chServerName,"OpenModelica.OPCUA.1");
	}
	// Clone the Server Name to WCHAR string to be used as the Program ID
	size_t len = strlen(chServerName);
	for (i=0; i<=len;i++) pWCHServerName[i] = (WCHAR) chServerName[i];
	
	// Check that the server is registered in NT Registry
	HKEY hProgId;	
	if (RegOpenKey (HKEY_CLASSES_ROOT, chServerName, &hProgId) != ERROR_SUCCESS) {		
		cout << "Invalid Server name" << endl;
		exit(-1);
	}
	cout << "Server name found in registry ok" << endl;

	// Get Memory Allocator, see COM documentation
	IMalloc *pMalloc;
	hres = CoGetMalloc(MEMCTX_TASK, &pMalloc);
	if(FAILED(hres)) 
	{
		cout << "CoGetMAlloc failed" << endl;
		exit(-1);
	}
	cout << "Memory Allocator ok" << endl;
	
	// Initialize COM Library, see COM documentation
	hres = CoInitialize(0);
	
	// Get Class ID by Program ID (server name), see COM documentation
	CLSID clsid;    
	hres = CLSIDFromProgID(pWCHServerName, &clsid);
	if(FAILED(hres)) 
	{
		cout << "Cannot get CLSID from PROGID" << endl;
		exit(-1);
	}
	cout << "CLSID found ok" << endl;
	
	// Create an OPC Sample Server Class Factory
	// See COM documentation for more on IClassFactory

	// The server can be local, remote or inproc 
	// This sample is for local server, i.e. another exe on the same host

	IClassFactory *pClassFactory = 0; 
	hres = CoGetClassObject(
		clsid,CLSCTX_LOCAL_SERVER,NULL,IID_IClassFactory,(void**)&pClassFactory);
	
	if (FAILED(hres))
	{
		cout << "Cannot create Class Factory " << endl;
		exit(-1);
	}
	cout << "Class Factory created ok" <<endl;

	// Use the Class Factory to create the OPC Server
	// Request an IUnknown Interface to it
	// See COM documentation for more on IUnknown 
	hres = pClassFactory->CreateInstance(NULL, IID_IUnknown, (void**)&pUnknown);
	
	// Release the Class Factory which is no longer needed
	pClassFactory->Release();
	pClassFactory = 0;
	
	if (FAILED(hres))
	{
		cout << "Cannot create OPC Server" << endl;
		exit(-1);
	}
	cout << "OPC Server created ok" <<endl;
	
	// See if the Server interface is supported and connect to opcserver
	// See OPC specification for more on IOPCServer
	IOPCServer *pOpcServer = 0;    
	hres = pUnknown->QueryInterface(IID_IOPCServer, (void**)&pOpcServer);
	if(FAILED(hres))
	{
		cout << "Cannot find OPC Server interface IOPCServer" << endl;
		pUnknown->Release();
		exit(-1);
	}
	cout << "OPC Server interface found ok" << endl; 
	
	// See if the Simulation Control interface is supported and fetch it
	ISimulationControl *pSimulationControl = 0;    
	hres = pUnknown->QueryInterface(IID_ISimulationControl, (void**)&pSimulationControl);

	if(FAILED(hres))
	{
		cout << "Cannot find Simulation Control interface ISimulationControl" << endl;
		pUnknown->Release();
		pOpcServer->Release();
		exit(-1);
	}
	cout << "Simulation Control interface found ok" << endl; 
	
	// Fetch the file management interface
	IPersistFile *pPersistFile = 0;    
	hres = pUnknown->QueryInterface(IID_IPersistFile, (void**)&pPersistFile);

	// Now that we have obtained all interfaces from the IUnknown returned by CreateInstance,
	// pUnknown can be released. This will not kill the OPC Server process as long as we have
	// at least one valid interface pointer from the process. 
	//
	// It is a good practice to release each interface as soon as it is no longer needed, and
	// releasing will not kill the component.
	pUnknown->Release();

	if(FAILED(hres))
	{
		cout << "Cannot find file management interface IPersistFile" << endl;
		pSimulationControl->Release();
		pOpcServer->Release();
		exit(-1);
	}
	cout << "File management interface found ok" << endl; 
	
	// Next, a group will be added to the server
	// See OPC specification for more on groups

	// Initial value for the update rate is 2 s.
	LPCWSTR szName = L"DemoGroup";      
	OPCHANDLE hClientGroup = 11110; 
	FLOAT fPercentDeadband = 0.0;
	OPCHANDLE hServerGroup;
	DWORD dwRevisedUpdateRate;

	// Instead of IUnknown, you may fetch any interface of interest 
	// by changing the last two parameters
	hres = pOpcServer->AddGroup(
		szName, TRUE, 2000, hClientGroup, 0, &fPercentDeadband,
		0, &hServerGroup, &dwRevisedUpdateRate, 
		IID_IUnknown,(LPUNKNOWN*)&pUnknown);

	// pOpcServer will not be needed for anything else, so it is best to release it
	pOpcServer->Release();

	if (FAILED(hres))
	{
		wcout << L"Cannot add group " << szName << endl; 
		cout << checkOpcHresult(hres) << endl;
		pSimulationControl->Release();
		pPersistFile->Release();
		exit(-1);
	}
	wcout << L"Group " << szName << L" added ok" << endl;

	// Get Synchronous IO interface needed for reading and writing data
	IOPCSyncIO *pOpcSyncIo = 0;
	hres = pUnknown->QueryInterface(IID_IOPCSyncIO, (void**)&pOpcSyncIo);
	if(FAILED(hres))
	{
		cout << "Cannot find Synchronous IO interface IOPCSyncIO" << endl;
		pUnknown->Release();
		pSimulationControl->Release();
		pPersistFile->Release();
		exit(-1);
	}
	cout << "Synchronous IO interface found ok" << endl;
		
	// Get ItemMgt interface needed for creating items
	IOPCItemMgt *pOpcItemMgt = 0;
	hres = pUnknown->QueryInterface(IID_IOPCItemMgt, (void**)&pOpcItemMgt);

	// Again, the pUnknown can be released because we have the IOPCSyncIO and IOPCItemMgt
	// pointers, and the pUnknown pointer will not be needed for anything else
	pUnknown->Release();

	if(FAILED(hres))
	{
		cout << "Cannot find Item Management interface IOPCItemMgt" << endl;
		pSimulationControl->Release();
		pPersistFile->Release();
		pOpcSyncIo->Release();
		exit(-1);
	}
	cout << "Item Management interface found ok" <<endl;

	// Create two items in the group
	// See OPC data Access Custom Interface specification 2.0 
	// for more on the OPC data types and operations
	WCHAR ItemIDs[2][40] = {L"load.phi",L"i1.v"};
	

	DWORD dwCount = 2L; 
	
	// Access path gives a hint to the server, where the item is located
	// The feature is optional, and it is not used in OpenModelica
	WCHAR AccessPaths[2][1] = {L"",L""};  
	
	// OPC data items are exchanged as Variants
	VARTYPE	dtype[2];               
	dtype[0] = VT_R8;				// The server will cast the data 
	dtype[1] = VT_R8;				//  into the requested data type

	// Arrays of operation results and error codes
	OPCITEMRESULT *pAddResults;   
	HRESULT *pErrors;			

	// Create and fill a definition struct for each item
	OPCITEMDEF itemArray[2];    
	itemArray[0].szItemID = ItemIDs[0];
	itemArray[0].szAccessPath = AccessPaths[0];		// Not used in OpenModelica
	itemArray[0].bActive = TRUE;
	itemArray[0].hClient = 100;						// Freely chosen client handle 
	itemArray[0].dwBlobSize = 0;					// Blobs can speed up processing of items,
	itemArray[0].pBlob = NULL;						//  but they are not used in OpenModelica
	itemArray[0].vtRequestedDataType = dtype[0];
	
	itemArray[1].szItemID = ItemIDs[1];
	itemArray[1].szAccessPath = AccessPaths[1];
	itemArray[1].bActive = TRUE;
	itemArray[1].hClient = 101;
	itemArray[1].dwBlobSize = 0;
	itemArray[1].pBlob = NULL;
	itemArray[1].vtRequestedDataType = dtype[1];

	// Before adding items, read the snapfile example and start simulation. 
	// The snapfile is read by using the COM standard interface IPersistFile, and
	// the simulation is started by using the extension interface for simulation control.

	// The access mode parameter is not supported by OpenModelica

	hres = pPersistFile->Load(L"example.dir\\example",0);

	// The file management interface will be no longer needed, so it is best to release it
	pPersistFile->Release();

	if (FAILED(hres)) 
	{
		cout << "Failed to load snapfile" << endl;
		cout << checkOpcHresult(hres) << endl;
		pSimulationControl->Release();
		pOpcItemMgt->Release();
		pOpcSyncIo->Release();
		exit(-1);
	} 
	cout << "Snapfile loaded ok" << endl;

	// The only parameter is the label for the synchronization point, not needed in this case
	hres = pSimulationControl->Run(-1);

/*	if (FAILED(hres)) 
	{
		cout << "Failed to start simulation" << endl;
		cout << checkOpcHresult(hres) << endl;
		pSimulationControl->Release();
		pOpcItemMgt->Release();
		pOpcSyncIo->Release();
		exit(-1);
	} 
	cout << "Simulation started ok" << endl;
*/
	// Add the items 
	hres = pOpcItemMgt->AddItems(dwCount, itemArray, &pAddResults, &pErrors);

	// pOpcItemMgt will not be needed for anything else, so it is best to release it
	pOpcItemMgt->Release();

	if (FAILED(hres)) 
	{
		cout << "Failed to add items" << endl;
		cout << checkOpcHresult(hres) << endl;
		pSimulationControl->Stop();
		pSimulationControl->Release();
		pOpcSyncIo->Release();
		exit(-1);
	} 

	// Returned Server Handles for the Items
	OPCHANDLE hServers[2];		        

	// Check the results of each item
	for(i=0; i<2; i++)  //Test if operation succeeded
	{
		if (FAILED(pErrors[i]))
		{
			wcout << L"Adding item " << ItemIDs[i] << L" failed" << endl;
			cout << checkOpcHresult(pErrors[i]) << endl;
			cout << "Before running this program, start OpenModelica." << endl;
			pSimulationControl->Stop();
			pSimulationControl->Release();
			pOpcSyncIo->Release();
			exit(-1);
		}
		else
		{
			// Store handle into global, will be needed when reading and writing
			hServers[i] = pAddResults[i].hServer;
				
			// Remember to free blob if it is returned!
			if(pAddResults[i].pBlob) pMalloc->Free(pAddResults[i].pBlob);

			wcout << L"Item " << ItemIDs[i] << L" added successfully" << endl;
			cout << "Server handle " << hServers[i] << endl;
			cout << "Canonical data type " << (DWORD)pAddResults[i].vtCanonicalDataType << endl;
			cout << "Access rights " << pAddResults[i].dwAccessRights << endl;
			cout << "Blob size " << pAddResults[i].dwBlobSize << endl << endl;
		}
	}
		
	// Client has to free all memory allocated [out] parameters
	// Therefore, free the returned HRESULTs and ITEMRESULTS
	pMalloc->Free(pAddResults);
	pMalloc->Free(pErrors);

	// Do synchronous reads and writes to new items

	// VARIANT is used in IOPCSyncIO::Write
	VARIANT	vInputValue;     
	// Data is written in in VT_R8 (REAL) type
	vInputValue.vt = VT_R8;  
	vInputValue.dblVal = 999999999;

	// OPC defined struct use by IOPCSyncIO::Read
	OPCITEMSTATE *pOutputValues; 
	
	cout << "The program will change one set point value  every 30 seconds" << endl;
	cout << "and read equivalent measurement value every 1.5 seconds" << endl;

	HRESULT *hr = new HRESULT[2];
	for(i=0;i<4;i++) {
		// The program changes the output power setpoint value.
		// The input behaves like rectangular wave. 
		if(vInputValue.dblVal > 900000001)
			vInputValue.dblVal = 900000000;
		else
			vInputValue.dblVal = 1000000000;
		
		// Does syncronous write to the "setpoint item" from DEVICE
		hres = pOpcSyncIo->Write(1, hServers, &vInputValue, &hr);
		if (FAILED(hres)) 
		{
			cout << "Error in Write" << endl;
			cout << checkOpcHresult(hres) << endl;
		}
		else if(FAILED(hr[0]))
		{
			cout << "Error in Write" << endl;
			cout << checkOpcHresult(hr[0]) << endl;
		}
		else 
			// COM Client has to free [out] parameter memory
			pMalloc->Free(hr);		
		
		for(j=0;j<20;j++) 
		{
			// Do synchronous read from CACHE (Could also be DEVICE) 
			hres = pOpcSyncIo->Read(OPC_DS_CACHE, 2, hServers, &pOutputValues, &hr);
			if (FAILED(hres)) 
			{
				cout << "Error in Read" << endl;
				cout << checkOpcHresult(hres) << endl;
			}
			else 
			{
				// if the read worked then show the results
				if(!FAILED(hr[0])) 
					cout << "Setpoint " << (&pOutputValues[0].vDataValue)->dblVal;
				if(!FAILED(hr[1])) 
					cout << " Measurement " << (&pOutputValues[1].vDataValue)->dblVal;
				cout << endl;
				
				// COM Client has to free [out] parameter memory
				pMalloc->Free(hr);
				VariantClear(&pOutputValues[0].vDataValue);	
				VariantClear(&pOutputValues[1].vDataValue);
				pMalloc->Free(pOutputValues);
			}
			Sleep(15);
		} // Read
		if(i==3)
		{
			char reply = '\0';
			cout << "Demo is over, do you wish to restart? (y/n)";
			cin >> reply;
			if(reply=='y') i=0;
		}
	} // Write

	pSimulationControl->Stop();
	char reply = '\0';
	cout << "r = run, o = stop, e = step, q = quit" << endl;
	while(reply != 'q') {
		cin >> reply;
		if(reply=='r') pSimulationControl->Run(-1);
		else if(reply=='o') pSimulationControl->Stop();
		else if(reply=='e') pSimulationControl->Step();
	}
	pSimulationControl->Stop();
	pSimulationControl->Release();
	pOpcSyncIo->Release();
	return 0;
}

