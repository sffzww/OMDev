SimpleOPCClient demonstrates implementation of OPCClient.
Use file SimpleOPCClient.cpp if you want to demonstrate standard OPC client
and SimpleOPCClientWithPersistFileAndSimulationControl.cpp if you
want to use PersistFile interface and SimulationControl interface.

Before you can run OPCClient you have to start an OpenModelica simulation with OPCKit

OPCClient connects by default to OpenModelica.OPCUA.1
This is default also in OpenModelica OPC.