// CheckHresult.h
//
// 
// A routine for retrieving information on the HRESULT return value of an OPC operation
// See winerror.h for more system error codes
//

#include "opcerror.h"

string checkOpcHresult(HRESULT r1)
{
	string message;
//
// start the message string with the severity code
//
	switch(HRESULT_SEVERITY(r1)) {
		case 0:
			message = "Success: ";
			break;
		case 1:
			message = "Information: ";
			break;
		case 2:
			message = "Warning: ";
			break;
		case 3:
			message = "Error: ";
			break;
		default:
			message = "Unknown severity: ";
	}
//
// Append a description
//
	switch(HRESULT(r1)) {
		case OPC_E_INVALIDHANDLE:
			message += "OPC_E_INVALIDHANDLE, The value of the handle is invalid. ";
			break;
		case OPC_E_BADTYPE:
			message += "OPC_E_BADTYPE, The server cannot convert the data between the requested data type and the canonical data type. ";
			break;
		case OPC_E_PUBLIC:
			message += "OPC_E_PUBLIC, The requested operation cannot be done on a public group. ";
			break;
		case OPC_E_BADRIGHTS:
			message += "OPC_E_BADRIGHTS, The Items AccessRights do not allow the operation. ";
			break;
		case OPC_E_UNKNOWNITEMID:
			message += "OPC_E_UNKNOWNITEMID, The item is no longer available in the server address space. ";
			break;
		case OPC_E_INVALIDITEMID:
			message += "OPC_E_INVALIDITEMID, The item definition doesn't conform to the server's syntax. ";
			break;
		case OPC_E_INVALIDFILTER:
			message += "OPC_E_INVALIDFILTER, The filter string was not valid. ";
			break;
		case OPC_E_UNKNOWNPATH:
			message += "OPC_E_UNKNOWNPATH, The item's access path is not known to the server. ";
			break;
		case OPC_E_RANGE:
			message += "OPC_E_RANGE, The value was out of range. ";
			break;
		case OPC_E_DUPLICATENAME:
			message += "OPC_E_DUPLICATENAME, Duplicate name not allowed. ";
			break;
		case OPC_S_UNSUPPORTEDRATE:
			message += "OPC_S_UNSUPPORTEDRATE, The server does not support the requested data rate but will use the closest available rate. ";
			break;
		case OPC_S_CLAMP:
			message += "OPC_S_CLAMP, A value passed to WRITE was accepted but the output was clamped. ";
			break;
		case OPC_S_INUSE:
			message += "OPC_S_INUSE, The operation cannot be completed because the object still has references that exist. ";
			break;
		case OPC_E_INVALIDCONFIGFILE:
			message += "OPC_E_INVALIDCONFIGFILE, The server's configuration file is an invalid format. ";
			break;
		case OPC_E_NOTFOUND:
			message += "OPC_E_NOTFOUND, The server could not locate the requested object. ";
			break;
		//Global HRESULTs
		case E_FAIL:
			message += "E_FAIL, Command failed. ";
			break;
		case E_OUTOFMEMORY:
			message += "E_OUTOFMEMORY, Not enough memory. ";
			break;
		case E_INVALIDARG:
			message += "E_INVALIDARG, An argument to the function was invalid. ";
			break;
		case S_FALSE:
			message += "S_FALSE, The operation completed with partial success. Refer to individual error returns for failure analysis. ";
			break;
		case E_NOINTERFACE:
			message += "E_NOINTERFACE, The interface asked for is not supported by the server. ";
			break;
		case S_OK:
			message += "S_OK ";
	}
	switch(HRESULT_FACILITY(r1)) {
		case FACILITY_NULL:
			message += "FACILITY_NULL ";//, with error code ";
			return message;
		case FACILITY_ITF:
			message += "FACILITY_ITF ";//, with error code ";
			return message;
		case FACILITY_DISPATCH:
			message += "FACILITY_DISPATCH ";//, with error code ";
			return message;
		case FACILITY_RPC :
			message += "FACILITY_RPC ";//, with error code ";
			return message;
		case FACILITY_STORAGE:
			message += "FACILITY_STORAGE ";//, with error code ";
			return message;
		case FACILITY_WINDOWS:
			message += "FACILITY_WINDOWS ";//, with error code ";
			return message;
		case FACILITY_WIN32:
			message += "FACILITY_WIN32 ";//, with error code ";
			return message;
		default:
			message = "Unknown facility error ";// with error code ";
			return message;
		}
}
