/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Tue Jun 04 20:00:46 2002
 */
/* Compiler settings for D:\OPCServer2\OPCExt2\Opcext2.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __Opcext2_h__
#define __Opcext2_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ISimulationControl_FWD_DEFINED__
#define __ISimulationControl_FWD_DEFINED__
typedef interface ISimulationControl ISimulationControl;
#endif 	/* __ISimulationControl_FWD_DEFINED__ */


#ifndef __ITrainingControlCallBack_FWD_DEFINED__
#define __ITrainingControlCallBack_FWD_DEFINED__
typedef interface ITrainingControlCallBack ITrainingControlCallBack;
#endif 	/* __ITrainingControlCallBack_FWD_DEFINED__ */


#ifndef __ITrainingControl_FWD_DEFINED__
#define __ITrainingControl_FWD_DEFINED__
typedef interface ITrainingControl ITrainingControl;
#endif 	/* __ITrainingControl_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

/* interface __MIDL_itf_Opcext2_0000 */
/* [local] */ 

typedef /* [public][public][public] */ 
enum __MIDL___MIDL_itf_Opcext2_0000_0001
    {	SC_STOPPED	= 1,
	SC_RUNNING	= SC_STOPPED + 1,
	SC_STOPPED_RECORDING	= SC_RUNNING + 1,
	SC_RUNNING_RECORDING	= SC_STOPPED_RECORDING + 1,
	SC_STOPPED_PLAYING	= SC_RUNNING_RECORDING + 1,
	SC_RUNNING_PLAYING	= SC_STOPPED_PLAYING + 1,
	SC_BUSY	= SC_RUNNING_PLAYING + 1,
	SC_UNKNOWN	= SC_BUSY + 1
    }	SCSIMULATORSTATEINFO;

typedef /* [public][public][public] */ 
enum __MIDL___MIDL_itf_Opcext2_0000_0002
    {	TC_ACTIVE	= 1,
	TC_DISABLED	= TC_ACTIVE + 1,
	TC_TRIGGERED	= TC_DISABLED + 1
    }	TCSTATE;

typedef /* [public][public][public] */ struct  __MIDL___MIDL_itf_Opcext2_0000_0003
    {
    DWORD dwNumConditionProps;
    /* [size_is] */ LPWSTR __RPC_FAR *pPropertyNames;
    /* [size_is] */ VARIANT __RPC_FAR *pConditionProperties;
    }	TCCONDITION;



extern RPC_IF_HANDLE __MIDL_itf_Opcext2_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_Opcext2_0000_v0_0_s_ifspec;

#ifndef __ISimulationControl_INTERFACE_DEFINED__
#define __ISimulationControl_INTERFACE_DEFINED__

/* interface ISimulationControl */
/* [unique][uuid][object] */ 


EXTERN_C const IID IID_ISimulationControl;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("416E6DA4-F554-11d5-BBF0-00010235E49A")
    ISimulationControl : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Run( 
            /* [in] */ FLOAT fDuration) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Stop( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Step( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSimulatorStateInfo( 
            /* [out] */ SCSIMULATORSTATEINFO __RPC_FAR *peSimulatorStateInfo) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE QueryAvailableSimulationItemIDs( 
            /* [out] */ DWORD __RPC_FAR *pdwCount,
            /* [size_is][size_is][out] */ DWORD __RPC_FAR *__RPC_FAR *ppdwSimulationProperties,
            /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszSimulationItemIDs,
            /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszDescriptions,
            /* [size_is][size_is][out] */ VARTYPE __RPC_FAR *__RPC_FAR *ppvtDataTypes) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ExecuteSimulatorCommand( 
            /* [string][in] */ LPCWSTR szCommand,
            /* [string][out] */ LPWSTR __RPC_FAR *pszReply) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISimulationControlVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISimulationControl __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISimulationControl __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISimulationControl __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Run )( 
            ISimulationControl __RPC_FAR * This,
            /* [in] */ FLOAT fDuration);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Stop )( 
            ISimulationControl __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Step )( 
            ISimulationControl __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetSimulatorStateInfo )( 
            ISimulationControl __RPC_FAR * This,
            /* [out] */ SCSIMULATORSTATEINFO __RPC_FAR *peSimulatorStateInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryAvailableSimulationItemIDs )( 
            ISimulationControl __RPC_FAR * This,
            /* [out] */ DWORD __RPC_FAR *pdwCount,
            /* [size_is][size_is][out] */ DWORD __RPC_FAR *__RPC_FAR *ppdwSimulationProperties,
            /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszSimulationItemIDs,
            /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszDescriptions,
            /* [size_is][size_is][out] */ VARTYPE __RPC_FAR *__RPC_FAR *ppvtDataTypes);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ExecuteSimulatorCommand )( 
            ISimulationControl __RPC_FAR * This,
            /* [string][in] */ LPCWSTR szCommand,
            /* [string][out] */ LPWSTR __RPC_FAR *pszReply);
        
        END_INTERFACE
    } ISimulationControlVtbl;

    interface ISimulationControl
    {
        CONST_VTBL struct ISimulationControlVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISimulationControl_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISimulationControl_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISimulationControl_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISimulationControl_Run(This,fDuration)	\
    (This)->lpVtbl -> Run(This,fDuration)

#define ISimulationControl_Stop(This)	\
    (This)->lpVtbl -> Stop(This)

#define ISimulationControl_Step(This)	\
    (This)->lpVtbl -> Step(This)

#define ISimulationControl_GetSimulatorStateInfo(This,peSimulatorStateInfo)	\
    (This)->lpVtbl -> GetSimulatorStateInfo(This,peSimulatorStateInfo)

#define ISimulationControl_QueryAvailableSimulationItemIDs(This,pdwCount,ppdwSimulationProperties,ppszSimulationItemIDs,ppszDescriptions,ppvtDataTypes)	\
    (This)->lpVtbl -> QueryAvailableSimulationItemIDs(This,pdwCount,ppdwSimulationProperties,ppszSimulationItemIDs,ppszDescriptions,ppvtDataTypes)

#define ISimulationControl_ExecuteSimulatorCommand(This,szCommand,pszReply)	\
    (This)->lpVtbl -> ExecuteSimulatorCommand(This,szCommand,pszReply)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ISimulationControl_Run_Proxy( 
    ISimulationControl __RPC_FAR * This,
    /* [in] */ FLOAT fDuration);


void __RPC_STUB ISimulationControl_Run_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISimulationControl_Stop_Proxy( 
    ISimulationControl __RPC_FAR * This);


void __RPC_STUB ISimulationControl_Stop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISimulationControl_Step_Proxy( 
    ISimulationControl __RPC_FAR * This);


void __RPC_STUB ISimulationControl_Step_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISimulationControl_GetSimulatorStateInfo_Proxy( 
    ISimulationControl __RPC_FAR * This,
    /* [out] */ SCSIMULATORSTATEINFO __RPC_FAR *peSimulatorStateInfo);


void __RPC_STUB ISimulationControl_GetSimulatorStateInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISimulationControl_QueryAvailableSimulationItemIDs_Proxy( 
    ISimulationControl __RPC_FAR * This,
    /* [out] */ DWORD __RPC_FAR *pdwCount,
    /* [size_is][size_is][out] */ DWORD __RPC_FAR *__RPC_FAR *ppdwSimulationProperties,
    /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszSimulationItemIDs,
    /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszDescriptions,
    /* [size_is][size_is][out] */ VARTYPE __RPC_FAR *__RPC_FAR *ppvtDataTypes);


void __RPC_STUB ISimulationControl_QueryAvailableSimulationItemIDs_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISimulationControl_ExecuteSimulatorCommand_Proxy( 
    ISimulationControl __RPC_FAR * This,
    /* [string][in] */ LPCWSTR szCommand,
    /* [string][out] */ LPWSTR __RPC_FAR *pszReply);


void __RPC_STUB ISimulationControl_ExecuteSimulatorCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISimulationControl_INTERFACE_DEFINED__ */


#ifndef __ITrainingControlCallBack_INTERFACE_DEFINED__
#define __ITrainingControlCallBack_INTERFACE_DEFINED__

/* interface ITrainingControlCallBack */
/* [unique][uuid][object] */ 


EXTERN_C const IID IID_ITrainingControlCallBack;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("416E6DA5-F554-11d5-BBF0-00010235E49A")
    ITrainingControlCallBack : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE ActionLog( 
            /* [in] */ LPWSTR szMessage) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SimulatorStateChange( 
            /* [in] */ FLOAT fSimulationTime,
            /* [in] */ SCSIMULATORSTATEINFO eSimulatorStateInfo) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITrainingControlCallBackVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITrainingControlCallBack __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITrainingControlCallBack __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITrainingControlCallBack __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ActionLog )( 
            ITrainingControlCallBack __RPC_FAR * This,
            /* [in] */ LPWSTR szMessage);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SimulatorStateChange )( 
            ITrainingControlCallBack __RPC_FAR * This,
            /* [in] */ FLOAT fSimulationTime,
            /* [in] */ SCSIMULATORSTATEINFO eSimulatorStateInfo);
        
        END_INTERFACE
    } ITrainingControlCallBackVtbl;

    interface ITrainingControlCallBack
    {
        CONST_VTBL struct ITrainingControlCallBackVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITrainingControlCallBack_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITrainingControlCallBack_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITrainingControlCallBack_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITrainingControlCallBack_ActionLog(This,szMessage)	\
    (This)->lpVtbl -> ActionLog(This,szMessage)

#define ITrainingControlCallBack_SimulatorStateChange(This,fSimulationTime,eSimulatorStateInfo)	\
    (This)->lpVtbl -> SimulatorStateChange(This,fSimulationTime,eSimulatorStateInfo)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ITrainingControlCallBack_ActionLog_Proxy( 
    ITrainingControlCallBack __RPC_FAR * This,
    /* [in] */ LPWSTR szMessage);


void __RPC_STUB ITrainingControlCallBack_ActionLog_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITrainingControlCallBack_SimulatorStateChange_Proxy( 
    ITrainingControlCallBack __RPC_FAR * This,
    /* [in] */ FLOAT fSimulationTime,
    /* [in] */ SCSIMULATORSTATEINFO eSimulatorStateInfo);


void __RPC_STUB ITrainingControlCallBack_SimulatorStateChange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITrainingControlCallBack_INTERFACE_DEFINED__ */


#ifndef __ITrainingControl_INTERFACE_DEFINED__
#define __ITrainingControl_INTERFACE_DEFINED__

/* interface ITrainingControl */
/* [unique][uuid][object] */ 


EXTERN_C const IID IID_ITrainingControl;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("416E6DA6-F554-11d5-BBF0-00010235E49A")
    ITrainingControl : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE QueryAvailableRecordingItemIDs( 
            /* [out] */ DWORD __RPC_FAR *pdwCount,
            /* [size_is][size_is][out] */ DWORD __RPC_FAR *__RPC_FAR *ppdwRecordingProperties,
            /* [size_is][size_is][string][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszRecordingItemIDs,
            /* [size_is][size_is][string][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszDescriptions,
            /* [size_is][size_is][out] */ VARTYPE __RPC_FAR *__RPC_FAR *ppvtDataTypes) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RecordingStart( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RecordingStop( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Wind( 
            /* [in] */ FLOAT fRequestedTime,
            /* [out] */ FLOAT __RPC_FAR *pfRevisedTime) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetRecordingRange( 
            /* [out] */ FLOAT __RPC_FAR *pfBeginTime,
            /* [out] */ FLOAT __RPC_FAR *pfEndTime) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RePlay( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ListMalfunctions( 
            /* [out] */ DWORD __RPC_FAR *pdwCount,
            /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszMalfunctionNames,
            /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszMalfunctionDescs) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetMalfunctionState( 
            /* [in] */ LPWSTR szName,
            /* [out] */ TCSTATE __RPC_FAR *peState) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetMalfunctionState( 
            /* [in] */ LPWSTR szName,
            /* [in] */ TCSTATE eState) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE QueryAvailableConditionProperties( 
            /* [out] */ DWORD __RPC_FAR *pdwCount,
            /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszPropName,
            /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszPropDesc,
            /* [size_is][size_is][out] */ VARTYPE __RPC_FAR *__RPC_FAR *ppvtPropTypes) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetConditions( 
            /* [in] */ LPWSTR szName,
            /* [out] */ TCCONDITION __RPC_FAR *peCondition) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetConditions( 
            /* [in] */ LPWSTR szName,
            /* [in] */ TCCONDITION eCondition) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITrainingControlVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITrainingControl __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITrainingControl __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITrainingControl __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryAvailableRecordingItemIDs )( 
            ITrainingControl __RPC_FAR * This,
            /* [out] */ DWORD __RPC_FAR *pdwCount,
            /* [size_is][size_is][out] */ DWORD __RPC_FAR *__RPC_FAR *ppdwRecordingProperties,
            /* [size_is][size_is][string][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszRecordingItemIDs,
            /* [size_is][size_is][string][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszDescriptions,
            /* [size_is][size_is][out] */ VARTYPE __RPC_FAR *__RPC_FAR *ppvtDataTypes);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RecordingStart )( 
            ITrainingControl __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RecordingStop )( 
            ITrainingControl __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Wind )( 
            ITrainingControl __RPC_FAR * This,
            /* [in] */ FLOAT fRequestedTime,
            /* [out] */ FLOAT __RPC_FAR *pfRevisedTime);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetRecordingRange )( 
            ITrainingControl __RPC_FAR * This,
            /* [out] */ FLOAT __RPC_FAR *pfBeginTime,
            /* [out] */ FLOAT __RPC_FAR *pfEndTime);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RePlay )( 
            ITrainingControl __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ListMalfunctions )( 
            ITrainingControl __RPC_FAR * This,
            /* [out] */ DWORD __RPC_FAR *pdwCount,
            /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszMalfunctionNames,
            /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszMalfunctionDescs);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetMalfunctionState )( 
            ITrainingControl __RPC_FAR * This,
            /* [in] */ LPWSTR szName,
            /* [out] */ TCSTATE __RPC_FAR *peState);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetMalfunctionState )( 
            ITrainingControl __RPC_FAR * This,
            /* [in] */ LPWSTR szName,
            /* [in] */ TCSTATE eState);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryAvailableConditionProperties )( 
            ITrainingControl __RPC_FAR * This,
            /* [out] */ DWORD __RPC_FAR *pdwCount,
            /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszPropName,
            /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszPropDesc,
            /* [size_is][size_is][out] */ VARTYPE __RPC_FAR *__RPC_FAR *ppvtPropTypes);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetConditions )( 
            ITrainingControl __RPC_FAR * This,
            /* [in] */ LPWSTR szName,
            /* [out] */ TCCONDITION __RPC_FAR *peCondition);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetConditions )( 
            ITrainingControl __RPC_FAR * This,
            /* [in] */ LPWSTR szName,
            /* [in] */ TCCONDITION eCondition);
        
        END_INTERFACE
    } ITrainingControlVtbl;

    interface ITrainingControl
    {
        CONST_VTBL struct ITrainingControlVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITrainingControl_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITrainingControl_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITrainingControl_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITrainingControl_QueryAvailableRecordingItemIDs(This,pdwCount,ppdwRecordingProperties,ppszRecordingItemIDs,ppszDescriptions,ppvtDataTypes)	\
    (This)->lpVtbl -> QueryAvailableRecordingItemIDs(This,pdwCount,ppdwRecordingProperties,ppszRecordingItemIDs,ppszDescriptions,ppvtDataTypes)

#define ITrainingControl_RecordingStart(This)	\
    (This)->lpVtbl -> RecordingStart(This)

#define ITrainingControl_RecordingStop(This)	\
    (This)->lpVtbl -> RecordingStop(This)

#define ITrainingControl_Wind(This,fRequestedTime,pfRevisedTime)	\
    (This)->lpVtbl -> Wind(This,fRequestedTime,pfRevisedTime)

#define ITrainingControl_GetRecordingRange(This,pfBeginTime,pfEndTime)	\
    (This)->lpVtbl -> GetRecordingRange(This,pfBeginTime,pfEndTime)

#define ITrainingControl_RePlay(This)	\
    (This)->lpVtbl -> RePlay(This)

#define ITrainingControl_ListMalfunctions(This,pdwCount,ppszMalfunctionNames,ppszMalfunctionDescs)	\
    (This)->lpVtbl -> ListMalfunctions(This,pdwCount,ppszMalfunctionNames,ppszMalfunctionDescs)

#define ITrainingControl_GetMalfunctionState(This,szName,peState)	\
    (This)->lpVtbl -> GetMalfunctionState(This,szName,peState)

#define ITrainingControl_SetMalfunctionState(This,szName,eState)	\
    (This)->lpVtbl -> SetMalfunctionState(This,szName,eState)

#define ITrainingControl_QueryAvailableConditionProperties(This,pdwCount,ppszPropName,ppszPropDesc,ppvtPropTypes)	\
    (This)->lpVtbl -> QueryAvailableConditionProperties(This,pdwCount,ppszPropName,ppszPropDesc,ppvtPropTypes)

#define ITrainingControl_GetConditions(This,szName,peCondition)	\
    (This)->lpVtbl -> GetConditions(This,szName,peCondition)

#define ITrainingControl_SetConditions(This,szName,eCondition)	\
    (This)->lpVtbl -> SetConditions(This,szName,eCondition)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ITrainingControl_QueryAvailableRecordingItemIDs_Proxy( 
    ITrainingControl __RPC_FAR * This,
    /* [out] */ DWORD __RPC_FAR *pdwCount,
    /* [size_is][size_is][out] */ DWORD __RPC_FAR *__RPC_FAR *ppdwRecordingProperties,
    /* [size_is][size_is][string][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszRecordingItemIDs,
    /* [size_is][size_is][string][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszDescriptions,
    /* [size_is][size_is][out] */ VARTYPE __RPC_FAR *__RPC_FAR *ppvtDataTypes);


void __RPC_STUB ITrainingControl_QueryAvailableRecordingItemIDs_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITrainingControl_RecordingStart_Proxy( 
    ITrainingControl __RPC_FAR * This);


void __RPC_STUB ITrainingControl_RecordingStart_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITrainingControl_RecordingStop_Proxy( 
    ITrainingControl __RPC_FAR * This);


void __RPC_STUB ITrainingControl_RecordingStop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITrainingControl_Wind_Proxy( 
    ITrainingControl __RPC_FAR * This,
    /* [in] */ FLOAT fRequestedTime,
    /* [out] */ FLOAT __RPC_FAR *pfRevisedTime);


void __RPC_STUB ITrainingControl_Wind_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITrainingControl_GetRecordingRange_Proxy( 
    ITrainingControl __RPC_FAR * This,
    /* [out] */ FLOAT __RPC_FAR *pfBeginTime,
    /* [out] */ FLOAT __RPC_FAR *pfEndTime);


void __RPC_STUB ITrainingControl_GetRecordingRange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITrainingControl_RePlay_Proxy( 
    ITrainingControl __RPC_FAR * This);


void __RPC_STUB ITrainingControl_RePlay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITrainingControl_ListMalfunctions_Proxy( 
    ITrainingControl __RPC_FAR * This,
    /* [out] */ DWORD __RPC_FAR *pdwCount,
    /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszMalfunctionNames,
    /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszMalfunctionDescs);


void __RPC_STUB ITrainingControl_ListMalfunctions_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITrainingControl_GetMalfunctionState_Proxy( 
    ITrainingControl __RPC_FAR * This,
    /* [in] */ LPWSTR szName,
    /* [out] */ TCSTATE __RPC_FAR *peState);


void __RPC_STUB ITrainingControl_GetMalfunctionState_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITrainingControl_SetMalfunctionState_Proxy( 
    ITrainingControl __RPC_FAR * This,
    /* [in] */ LPWSTR szName,
    /* [in] */ TCSTATE eState);


void __RPC_STUB ITrainingControl_SetMalfunctionState_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITrainingControl_QueryAvailableConditionProperties_Proxy( 
    ITrainingControl __RPC_FAR * This,
    /* [out] */ DWORD __RPC_FAR *pdwCount,
    /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszPropName,
    /* [size_is][size_is][out] */ LPWSTR __RPC_FAR *__RPC_FAR *ppszPropDesc,
    /* [size_is][size_is][out] */ VARTYPE __RPC_FAR *__RPC_FAR *ppvtPropTypes);


void __RPC_STUB ITrainingControl_QueryAvailableConditionProperties_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITrainingControl_GetConditions_Proxy( 
    ITrainingControl __RPC_FAR * This,
    /* [in] */ LPWSTR szName,
    /* [out] */ TCCONDITION __RPC_FAR *peCondition);


void __RPC_STUB ITrainingControl_GetConditions_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITrainingControl_SetConditions_Proxy( 
    ITrainingControl __RPC_FAR * This,
    /* [in] */ LPWSTR szName,
    /* [in] */ TCCONDITION eCondition);


void __RPC_STUB ITrainingControl_SetConditions_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITrainingControl_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
